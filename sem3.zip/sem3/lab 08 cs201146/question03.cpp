#include <iostream>
using namespace std;


char stack[100];
int top = -1;

void push(char a)
{
    stack[++top] = a;
}

char pop()
{
    if(top == -1)
        return -1;
    else
        return stack[top--];
}

int priority(char a)
{
    if(a == '(')
        return 0;
    if(a == '+' || a == '-')
        return 1;
    if(a == '*' || a == '/')
        return 2;
    return 0;
}

int main()
{
    char exp[100];
    char *ch, a;
   cout<<"Enter the expression : ";
    cin>>exp;
   cout<<"\n";
    ch = exp;
    
    while(*ch != '\0')
    {
        if(isalnum(*ch))
           cout<<*ch;
        else if(*ch == '(')
            push(*ch);
        else if(*ch == ')')
        {
            while((a = pop()) != '(')
               cout<<a;
        }
        else
        {
            while(priority(stack[top]) >= priority(*ch))
               cout<<pop();
            push(*ch);
        }
        ch++;
    }
    
    while(top != -1)
    {
       cout<<pop();
    }return 0;
}
