#include <iostream>
using namespace std;


struct Node
{
    int data;
    struct Node* link;
};
 
struct Node* top;
 

void push(int data)
{

    struct Node* temp;
    temp = new Node();
 
    if (!temp)
    {
        cout << "\n Overflow";
        exit(1);
    }
 
    
    temp->data = data;
 
    temp->link = top;
 
    
    top = temp;
}

int isEmpty()
{
    return top == NULL;
}
 

int peek()
{

    if (!isEmpty())
        return top->data;
    else
        exit(1);
}
 

void pop()
{
    struct Node* temp;
 
   
    if (top == NULL)
    {
        cout << "\nStack Underflow" << endl;
    
    }
    else
    {
         
        temp = top;
 
        top = top->link;
 
        temp->link = NULL;
 
    
    }
}

void display()
{
    struct Node* temp;
 
   
    if (top == NULL)
    {
        cout << "\nStack Underflow";
        exit(1);
    }
    else
    {
        temp = top;
        while (temp != NULL)
        {
 
            cout << temp->data << "-> ";
 
            temp = temp->link;
            if(temp == NULL)
   cout<<"NULL"<<endl;
        }
    }
}
 
int main()
{
     
    push(11);
    push(22);
    push(33);
    push(44);
   cout << "\ninsert stack using link list\n";
    display();
 
 
    pop();
    pop();
  cout << "\n delete node stack using link list\n";
    display();

          
    return 0;
}
