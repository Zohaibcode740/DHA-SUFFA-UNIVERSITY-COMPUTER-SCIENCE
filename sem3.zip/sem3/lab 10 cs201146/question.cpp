#include <bits/stdc++.h>
#include <iostream>
using namespace std;

class node
{
public:
    string info;
    node *left = NULL, *right = NULL;
    node(string x)
    {
        info = x;
    }
};
 
int value(string s)
{
    int num = 0;
         
    
    if(s[0]!='-'){
	
        for (int i=0; i<s.length(); i++){
		
            num = num*10 + (int(s[i])-48);
        }}
  
    else
        for (int i=1; i<s.length(); i++)
        {
            num = num*10 + (int(s[i])-48);
            num = num*-1;
        }
     
    return num;
}
 
int result(node* root)
{
    if (!root)
        return 0;
 
    if (!root->left && !root->right)
        return value(root->info);
 
    int lval = result(root->left);
 
    int rval = result(root->right);

    if (root->info=="+")
        return lval+rval;
 
    if (root->info=="-")
        return lval-rval;
 
    if (root->info=="*")
        return lval*rval;
        
    if (root->info=="/")
        return lval/rval;
 
    return lval/rval;
}
 

int main()
{
    // create a syntax tree
    node *root = new node("+");
    root->left = new node("/");
    root->left->left = new node("*");
    root->left->left->left = new node("2");
    root->left->left->right = new node("3");
    root->left->right = new node("-");
    root->left->right->right = new node("1");
    root->left->right->left = new node("2");
    
    root->right = new node("*");
    root->right->left = new node("5");
    root->right->right = new node("-");
    root->right->right->right = new node("1");
    root->right->right->left = new node("4");
    
    cout << result(root);
 
    
    return 0;
}
