
#include <iostream>
using namespace std;
  
  int bserach(int arr[10],int search)
       {
              int count;
             
              for(count=0;count<10;count++)
              {
                     if(search==arr[count])
                     {
                           return count;
             
                     }
              }
      
       return 0;    
       }


int main()
{
       int arr[10]={11,22,33,36,45,52,57,60,64,78}, searchl,serch, number;
      
       cout<<"Enter number to Search : ";
       cin>>number;


       searchl=bserach(arr,number);

    cout<<" Value found at index number : "<<searchl<<endl;



        
}
