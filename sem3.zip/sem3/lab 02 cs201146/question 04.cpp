
#include <iostream>
using namespace std;

void delarr(int* arr, int size, int index)
{
    int i;
    for (i=index-1; i<(size-1); i++)
	{
        arr[i]= arr[i+1];
    }
}

void printArray(int* arr,int size)
{
    for(int i=0; i<size-1; ++i)
    {
    	cout<<"Element at ["<<i+1<<"]: "<<arr[i]<<endl;
	}
}

int main ()
{
    int index;
    int size=10;
    int arr[10]={11,22,33,36,45,52,57,60,64,78};
    for (int i= 0; i<10; i++)
	{
        cout<<"Element at ["<<i+1<<"]: "<<arr[i]<<endl;
    }
    cout<<"Enter the index for delete: "<<endl;
    cin>>index;
    delarr(arr, size, index);
    printArray(arr,size);
    
    return 0;
}

