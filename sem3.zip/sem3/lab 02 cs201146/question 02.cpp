#include <iostream>

using namespace std;

int main()
{
   
   int array[100], search, c, n, count = 0;
   
   cout<<"Enter number of elements in array\n"<<endl;
   cin>>n;
   
   cout<<"Enter "<<n<<" numbers\n"<<endl;
   
   for (c = 0; c < n; c++){
       cin>>array[c];}
     
  cout<<"Enter a number to search\n"<<endl;
   cin>>search;
   
   for (c = 0; c < n; c++) {
      if (array[c] == search) {
         
         count++;
      }
   }
   if (count == 0){
     cout<<  "isn't present in the array."<<endl;}
   else{
      cout<< ""<<search<<" is present "<<count<<" times in the array"<<endl;}
     
   return 0;
}

