
#include <iostream>

using namespace std;
int binarySearch(int a[], int first, int last, int search_num)
{
   int mid;
   if(last >= first)
   {
      mid = (first + last)/2;
      if(a[mid] == search_num)
      {
         return mid+1;
      }
      else if(a[mid] < search_num)
      {
         return binarySearch(a,mid+1,last,search_num);
      }
      else
      {
         return binarySearch(a,first,mid-1,search_num);
      }

   }
   return -1;
}
void printArray(int *arr , int size){
    
    for(int i=0;i<size;++i)
    {
        std::cout<<"arr ["<<i<<"]= " <<arr[i] <<std::endl;
    }
}

int main()
{
   int size =10;
  int num[10] = {10, 22, 37, 55, 92, 118,62,58,32,47};
   int search_num, loc=-1;
   printArray(num,size);
   cout<<"Enter the number that you want to search: ";
   cin>>search_num;

   loc = binarySearch(num, 0, 6, search_num);

   if(loc != -1)
   {
      cout<<search_num<<" found in the array at the location: "<<loc;
   }
   else
   {
      cout<<"Element not found";
   }
   return 0;
}

