#include<iostream>
using namespace std;

int main()
{
	int size, i, vector1[10], vector2[10], vector[10];
	
	cout << "\nPlease Enter the Array Size =  ";
	cin >> size;
	
	cout << "\nPlease Enter the First Array Items =  ";
	for(i = 0; i < size; i++)
	{
		cin >> vector1[i];
	}	
	cout << "\nPlease Enter the Second Array Items =  ";
	for(i = 0; i < size; i++)
	{
		cin >> vector2[i];
	}
	cout << "\nThe Final Result of Multiplying two Arrays = ";
	for(i = 0; i < size; i++)
	{
		vector[i] = vector1[i] * vector2[i];
		cout << vector[i] << " ";
	}

 	return 0;
}
