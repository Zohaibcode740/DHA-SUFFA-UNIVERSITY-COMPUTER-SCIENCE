#include<iostream>
using namespace std;
int main(){
    int mat[2][2], i, j;
    float determinant = 0;
    cout<<"Enter elements of matrix row wise:\n";
    for(i = 0; i < 2; i++)
        for(j = 0; j < 2; j++)
           cin>>mat[i][j];
    
    cout<<"\nGiven matrix is:";
    for(i = 0; i < 2; i++){
        cout<<"\n";
        
        for(j = 0; j < 2; j++)
            cout<<mat[i][j]<<"\t";
    }
    
    for(i = 0; i < 2; i++)
        determinant = mat[0][0]*mat[1][1] - mat[1][0]*mat[0][1];
    
    cout<<"\n\ndeterminant: "<<determinant;
    
    
        float val1 = mat[0][0]/ determinant;
       float  val2 = mat[1][1] / determinant;
        float  val3 = mat[1][0] / determinant;
         float  val4 = mat[0][1] / determinant;
    cout<<"\n\nInverse of matrix is: \n";
    for(i = 0; i < 1; i++){
        for(j = 0; j < 1; j++)
           cout<<val2 <<"\t"<<"-"<<val4 <<"\n";
            cout<< "-"<<val3 <<"\t"<<val1;
           
        cout<<"\n";
    }
 
   return 0;
}
