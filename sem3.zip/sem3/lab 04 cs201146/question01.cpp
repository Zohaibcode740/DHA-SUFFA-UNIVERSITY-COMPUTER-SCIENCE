#include <iostream>

using namespace std;
 
int main() { 
   int arr1 [10], arr2 [10], arr3 [20]; 
   int i, n1, n2, m, index=0; 
  
   cout <<"\n Enter the number of elements in array 1: "; 
   cin >> n1; 
   cout <<"\n\n Enter the Elements of the first array: "; 
 
   for(i=0;i<n1;i++)  { 
     cin >> arr1[i]; 
   } 
   cout <<"\n Enter the number of elements in array 2: "; 
   cin >> n2 ; 
  cout <<"\n\n Enter the Elements of the second array: "; 
  
   for(i=0;i<n2;i++) { 
      cin >> arr2[i]; 
      m = n1+n2; 
   } 
   for(i=0;i<n1;i++) { 
     arr3[index]=arr1[i]; 
     index++; 
   } 
   for(i=0;i<n2;i++) { 
      arr3[index]=arr2[i]; 
      index++; 
   } 
   cout <<"\n\n The merged array is :\n"; 
  
   for(i=0;i<m;i++) { 
      std::cout<<"arr ["<<i<<"]= " <<arr3[i] <<std::endl;; 
   } 
    
     return 0; 
 }
