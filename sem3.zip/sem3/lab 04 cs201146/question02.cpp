#include <bits/stdc++.h>
using namespace std;
 
// Function to merge array in sorted order
void sortedMerge(int arr1[], int arr2[], int res[], int n, int m)
{
    int i = 0, j = 0, k = 0;
    while (i < n) {
        res[k] = arr1[i];
        i += 1;
        k += 1;
    }
    while (j < m) {
        res[k] = arr2[j];
        j += 1;
        k += 1;
    }
 
    sort(res, res + n + m);
}
 

int main()
{
    int arr1[5];
    int n1=5;
    int n2 =5;
     cout <<"\n\n Enter the 5 Elements of the first array: "; 
 
   for(int i=0;i<n1;i++)  { 
     cin >> arr1[i]; 
   } 
    int arr2[5];
     cout <<"\n\n Enter the 5 Elements of the second array: "; 
 
   for(int i=0;i<n2;i++)  { 
     cin >> arr2[i]; 
   } 
    int n = sizeof(arr1) / sizeof(arr1[0]);
    int m = sizeof(arr2) / sizeof(arr2[0]);
 
    int res[n + m];
    sortedMerge(arr1,arr2, res, n, m);
 
    cout << "Sorted merged list :";
    for (int i = 0; i < n + m; i++)
        cout << " " << res[i];
    
 
    return 0;
}
