 #include <iostream>
using namespace std;
int main()
{
    

    int a[2][2], i, j;
    long determinant;

   cout << "\n\nEnter the 4 elements of the array:\n";
    for(i = 0; i < 2; i++)
    for(j = 0; j < 2; j++)
    cin >> a[i][j];

    cout << "\n\nThe entered matrix is: \n\n";
    for(i = 0; i < 2; i++)
    {
        for(j = 0; j < 2; j++)
        {
            cout << "\t" <<a[i][j];
        }
        cout << "\n"; 
    }

    
    determinant = a[0][0]*a[1][1] - a[1][0]*a[0][1];
    cout << "\n\nDterminant of 2x2 matrix is :  "<< a[0][0]*a[1][1] <<"-" <<a[1][0]*a[0][1] <<"=" << determinant;

    
    return 0;
}
