#include <iostream>

using namespace std;
int *createArray(int size)
{
    int *arr= new int[size];
    for(int i = 0; i<size;++i){
        arr[i] = 0;
        return arr;
    }
    
}
void inserta (int *arr, int size, int index, int value)
{
int i;
for (i=size-1; i>index ;--i)
{
arr[i]= arr [i-1];
}
arr[index] = value;
}

void printArray(int *arr , int size){
    
    for(int i=0;i<size;++i)
    {
        std::cout<<"arr ["<<i<<"]= " <<arr[i] <<std::endl;
    }
}
   void arraycheck(int index ,int  size ){
       if(index > size)
       {
            std::cout<<" overflow error occurs"<<std::endl;  
          
       }
      
   } 
int main(){


//creating array
int size = 0, value = 0, index = 0;
char ch;

std::cout<<"Enter size of array:";
std::cin>>size;
int *arr = createArray(size);

printArray(arr,size);

//insertion in Array

do{
 
std::cout<<"Enter index you want to insert element at:";
std::cin>>index;
std::cout<<std::endl;

arraycheck(index,size);
if(index > size)
{
   goto jump;}
std::cout<<"Enter value you want to insert:";
std::cin>>value;
std::cout<<std::endl;



inserta(arr,size,index,value);

std::cout<<"Array after insertion"<<std::endl;

printArray(arr,size);
jump:
std::cout<<"Wish to insert again?(y/n):";
std::cin>>ch;


}
while(ch!='n');


return 0;
}

