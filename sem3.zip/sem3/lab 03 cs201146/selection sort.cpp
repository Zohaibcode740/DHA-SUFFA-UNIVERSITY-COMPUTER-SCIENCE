
#include <iostream>

using namespace std;


int main()
{
  int i, j, count, temp, number[25];

   cout<<"Enter number of elements: ";
   cin>>count;

   cout<<"Enter"<<count<<" elements: ";
  
   for(i=0;i<count;i++)
      cin>>number[i];
 

   for(i=0;i<count;i++){
      for(j=i+1;j<count;j++){
         if(number[i]>number[j]){
            temp=number[i];
            number[i]=number[j];
            number[j]=temp;
         }
      }
   }

   cout<<"Sorted elements: ";
   for(i=0;i<count;i++)
      cout<< ""<<number[i]<<"";

   return 0;
}

