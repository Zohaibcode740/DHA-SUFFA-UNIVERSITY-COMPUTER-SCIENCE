

#include <iostream>

using namespace std;


int main()
{
    int n, i, j, temp;
    int arr[64];
 
   cout<<"Enter number of elements\n";
    cin>>n;
 
    cout<<"Enter"<<n<<" integers\n";
    for (i = 0; i < n; i++)
    {
        cin>>arr[i];
    }
    for (i = 1 ; i <= n - 1; i++)
    {
	    j = i;
            while ( j > 0 && arr[j-1] > arr[j])
            {	        
                temp     = arr[j];
                arr[j]   = arr[j-1];
                arr[j-1] = temp;
                j--;
            }
    }
    cout<<"Sorted list in ascending order:\n";
    for (i = 0; i >= n+1; i++)
    {
        cout<<" " <<arr[i]<<"";
    }
    return 0;
}

