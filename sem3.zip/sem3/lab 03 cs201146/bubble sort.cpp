#include<iostream>
using namespace std;

int main ()
{
     int i, arr[10];
     int j, temp;
    cout<<"Enter 10 Elements: ";
    for(i=0; i<10; i++)
        cin>>arr[i];
   
    for(i=0; i<9; i++)
    {
        for(j=0; j<(10-i-1); j++)
        {
            if(arr[j]>arr[j+1])
            {
                temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
    cout<<"\nThe New Sorted Array is: \n";
    for(i=0; i<10; i++)
        cout<<arr[i]<<" ";
    cout<<endl;
    return 0;
}
