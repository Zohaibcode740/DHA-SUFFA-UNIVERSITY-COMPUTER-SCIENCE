#include <bits/stdc++.h>

using namespace std;
class BST
{
private:
    int data;
    BST *left;
    BST *right;

public:
    BST(int data)
    {
        this->data = data;
        left = nullptr;
        right = nullptr;
    }

    static BST *insert(BST *root, int val)
    {
        if (root == nullptr)
            return new BST(val);
        if (val < root->data)
        {
            root->left = BST::insert(root->left, val);
        }
        else
        {
            root->right = BST::insert(root->right, val);
        }
        return root;
    }

    static int height(BST *root)
    {
        if (root == nullptr)
            return 0;
        else
            return 1 + max(height(root->left), height(root->right));
    }

    static void preorder(BST *root)
    {
        if (root == nullptr)
            return;
        cout << root->data << " ";
        preorder(root->left);
        preorder(root->right);
    }

    static void postorder(BST *root)
    {
        if (root == nullptr)
            return;
        postorder(root->left);
        postorder(root->right);
        cout << root->data << " ";
    }

    static void inorder(BST *root)
    {
        if (root == nullptr)
            return;
        inorder(root->left);
        cout << root->data << " ";
        inorder(root->right);
    }

    static void printRightSubTree(BST *root)
    {
        if (root == nullptr || root->right == nullptr)
            return;

        BST *rightSubtree = root->right;

        cout << "Preorder: ";
        preorder(rightSubtree);
        cout << endl;

        cout << "Postorder: ";
        postorder(rightSubtree);
        cout << endl;

        cout << "Inorder: ";
        inorder(rightSubtree);
        cout << endl;
    }
};

int main()
{
    BST *root = nullptr;

    root = BST::insert(root, 21);
    root = BST::insert(root, 16);
    root = BST::insert(root, 2);
    root = BST::insert(root, 25);
    root = BST::insert(root, 30);
    root = BST::insert(root, 14);
    root = BST::insert(root, 2);
    root = BST::insert(root, 60);
    root = BST::insert(root, 8);
    root = BST::insert(root, 15);
    root = BST::insert(root, 35);
    root = BST::insert(root, 40);
    root = BST::insert(root, 100);
    root = BST::insert(root, 55);

    cout << "Height = " << BST::height(root)<<endl;

    BST::printRightSubTree(root);
}
