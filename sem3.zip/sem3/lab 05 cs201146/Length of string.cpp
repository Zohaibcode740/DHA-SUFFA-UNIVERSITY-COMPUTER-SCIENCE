#include <iostream>
#include <cstring>
using namespace std;

int main() {
    char Str[50]="Hello world!";
    char Str2[50]="DHA suffa";
    
    
    int i;
    int j;
    int sum;
  
     
for (i = 0; Str[i] != '\0'; ++i);
  for (j = 0; Str2[j] != '\0'; ++j);
     cout <<"Length of Str 1 is: "<< i;
     cout <<"\n Length of Str 2 is: "<< j;
     sum =i+j;
     cout <<"\n sum of to string length: "<< sum;
     
     
     
    return 0;
}
