#include <iostream>

using namespace std;
int main() {
  char s1[100] = "DHa", s2[] = "Suffa";
  int length=0 ;
  
  int j ;
  while (s1[length] != '\0') {
    ++length;
  }

  // concatenate s2 to s1
  for (j = 0; s2[j] != '\0'; ++j, ++length) {
    s1[length] = s2[j];
  }

  // terminating the s1 string
  s1[length] = '\0';

  cout<<"After concatenation: " << s1;


  return 0;
}
