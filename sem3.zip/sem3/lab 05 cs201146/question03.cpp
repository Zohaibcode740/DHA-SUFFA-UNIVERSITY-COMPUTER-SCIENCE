#include <iostream>
#include <bits/stdc++.h>
using namespace std;
int main() {
    string Str="or";
    string Str2 ="hello world";
    
    
    int su= Str.size();
	int T= Str2.size() ;
for (int i = 0; i< T-su+1; i++){

  if(Str2.substr(i,su) == Str)
  {
  	 cout <<"substring Str 2 is: "<< i;
  }
}
     
     
     
    return 0;
}
