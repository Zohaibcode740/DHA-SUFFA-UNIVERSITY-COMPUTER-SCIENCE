  class Area
{

    void display(int l, int b)
    {
        System.out.println("Area of Rectangle is = "+l*b);
    }

    void display(int a)
    {
        System.out.println("Area of Square is = "+a*a);
    }
}

class p2{
public static void main(String[] args)
{
    Area ar = new Area();
    ar.display(2,4);
    ar.display(2);
}               

}