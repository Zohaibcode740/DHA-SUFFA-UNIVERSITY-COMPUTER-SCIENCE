import java.util.*;
class Rectangle
{
    int l,b;
    Rectangle(int x, int y)
    {
       this.l=x;
        this.b=y;
    }

    void area()
    {
        System.out.println(l*b);
    }

    void perimeter()
    {
        System.out.println(2*(l+b));
    }
}

class square extends Rectangle
{
	public square(int s)
	{
		super(s,s);
	}
}

class p1{
public static void main(String[] args)
{
    Rectangle r = new Rectangle(5,2);
    square s = new square(2);
    r.area();
    r.perimeter();
    s.area();
    s.perimeter();
}   
}              

