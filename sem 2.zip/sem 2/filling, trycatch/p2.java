
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.util.*;
class Record{
	public void readfromfile(){
	   try {
      File read = new File("F:\\filename.txt");
      Scanner myReader = new Scanner(read);
      while (myReader.hasNextLine()) {
        String data = myReader.nextLine();
        System.out.println(data);
      }
      myReader.close();
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
	}
	
	
	public void writetofile(){
		try {
      FileWriter Write = new FileWriter("F:\\filename.txt");
      Write.write("java lab 9");
      Write.close();
      System.out.println("Successfully wrote to the file.");
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
	}
}


public class p2 {
  public static void main(String[] args) {
    try {
      File Obj = new File("F:\\filename.txt");
      if (Obj.createNewFile()) {
        System.out.println("File created: " + Obj.getName());
      } else {
        System.out.println("File already exists.");
      }
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
	
	Record re = new Record();
	re.writetofile();
	re.readfromfile();
	
  }
}