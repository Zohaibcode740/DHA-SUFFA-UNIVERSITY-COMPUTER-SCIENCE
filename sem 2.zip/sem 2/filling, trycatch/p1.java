 class Car {

    private int year;

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    private String model;

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }
    private float price;

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    private String color;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    private Engine engine;

    public Car() {
       
        System.out.println("CAr Name:Audi");
    }

    public Car(int year, String model, float price, String color) {
        this.year = year;
        this.model = model;
        this.price = price;
        this.color = color;
    }

    public void display() { 
        System.out.println("***** Car Info *****");
         System.out.println("Car year: " + year);
        System.out.println("Car color: " + color);
        System.out.println("Car model: " + model);
        System.out.println("Car price:" + price);
    }

    public void start() {
        System.out.println("The Car Method Start");
    }

    public void stop() {
        System.out.println("The Car Method Stop");
    }
}

class Engine {

    private String modelnumber;

    public String getModelnumber() {
        return modelnumber;
    }

    public void setModelnumber(String modelnumber) {
        this.modelnumber = modelnumber;
    }

    public Engine() {
        System.out.println("Engine");
    }

    Engine(String model_number) {
        this.modelnumber = modelnumber;
    }

    public void start() {
      
        System.out.println("The Engine  Start");
    }

    public void stop() {
        System.out.println("The Engine Stop");
        
    }
}

public class p2 {

    public static void main(String[] args) {
         
        Car carobj = new Car(2020,"Al23",2000000,"Blue");
        carobj.start();
        carobj.display();
       
        carobj.stop();
        

        Engine engobj = new Engine();
        engobj.setModelnumber("V12 Engine");
          engobj.start();
        System.out.println("****** Engine Details *****");
        System.out.println("Engine Modle: " + engobj.getModelnumber());
     
      
        engobj.stop();

    }
}