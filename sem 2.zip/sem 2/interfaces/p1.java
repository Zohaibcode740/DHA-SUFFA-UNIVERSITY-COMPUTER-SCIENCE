interface Animal{
    void eat();
    void travel();
}
abstract class eat implements Animal{

   
    public void eat() {
        System.out.println("grass");
    }
	

}

class reptiles extends eat {

   
    public void eat() {
   super.eat();

    }

   
    public void travel() {
       System.out.println("land");
    }

}
class bird extends eat {

   
    public void eat() {
        System.out.println("seed");
    }

   
    public void travel() {
        System.out.println("flying");
    }

}
class fish extends eat {

   
    public void eat() {
        System.out.println("seed");
    }

   
    public void travel() {
        System.out.println("swimming");
    }

}
public class p1 {

    public static void main(String[] args) {
        Animal[] ani = new Animal[3];
        ani[0] = new reptiles();
        ani[1] = new bird();
        ani[2] = new fish();
        
for (int i = 0; i < ani.length; i++) {
            ani[i].eat();
			ani[i].travel();
			
        }
       
    }

}