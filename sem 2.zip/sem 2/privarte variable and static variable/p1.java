class Rectangle 
 { 
       int length; 
       static int breadth;
			   
       
        Rectangle(int l, int b) 
       {  
         this.length = l; 
         this.breadth = b; 
       } 
     
       int area() 
       { 
         int rectArea; 
         rectArea = length * breadth; 
         return rectArea; 
       } 
 } 
 
 class p1
 { 
          public static void main(String[] args) 
      { 
            //Creating objects 
            Rectangle rect = new Rectangle(5,6); 
           
            int result = rect.area(); 
            System.out.println("Area of Rectangle = "+ result); 
      } 
 } 