class Time {
    private int hour = 0;
    private int minute = 0;
    private int second = 0;

    Time(int h, int m, int s) {
        hour = h;
        minute = m;
        second = s;
    }

    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }

    public int getSecond() {
        return second;
    }

    public void setHour(int newHour) {
        hour = newHour;
    }

    public void setMinute(int newMinute) {
        minute = newMinute;
    }

    public void setSecond(int newSecond) {
        second = newSecond;
    }

   
    
}
class p2
 { 
  
 public static void main(String[] args) {
        Time ti = new Time(7, 47, 00);
        ti.setHour(07);
        ti.setMinute(47);
        ti.setSecond(00);
        System.out.print("TIME:" + ti.getHour());
        System.out.print(":" + ti.getMinute());
        System.out.println(":" + ti.getSecond());

    }
 }
